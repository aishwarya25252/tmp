import json
import dao 
import numpy as np
import pandas as pd
import generate_happytransformer
from fastapi import FastAPI, BackgroundTasks,Request
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware

DEV_MODE=0

app = FastAPI()

def get_softskills(selected_id):
    interview_id=selected_id
 ##      a.caracteristic, a.ranks 
    sql = """
      select Distinct
      a.caracteristic, a.ranks
      from interview_B56SK a 
      where interview_id = '{}' 
      and lower(caracteristic_type) = 'soft skill'
      """.format(interview_id)  
    
    df = dao.get_data(sql)
#    print('Softskills')
#    print(df)
    high_score = (df.loc[df['ranks'] >= 7])
#    print('High Score')
#    print(high_score)
    high_score_flt = high_score[high_score['caracteristic'].isin(['Leadership', 'Growth Potential'])]
#    print('Filtered')
#    print(high_score_flt)
    list_pos = high_score_flt['caracteristic']
#    print('Returned List Pos')
#    print(list_pos)
# Low score for Leadership and Growth Potential
    low_score = (df.loc[df['ranks'] <= 4])
#    print('Low Score')
#    print(low_score)
    low_score_flt = low_score[low_score['caracteristic'].isin(['Leadership', 'Growth Potential'])]
#    print('Filtered')
#    print(low_score_flt)
    list_neg = low_score_flt['caracteristic']
#    print('Returned List Neg')
#    print(list_neg)    
    return (list_pos, list_neg)

def get_psychometrics(selected_id):
    interview_id=selected_id

    sql = """
      select Distinct               
      vmk.variable_label variable
      , a.mean 
      ,round(-1*a.std::numeric, 4) std
      ,a.ranks
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      order by a.ranks desc
      """.format(interview_id)
      
    df = dao.get_data(sql)
    high_score = (df.loc[df['ranks'] >= 9])
    high_score.drop(high_score.index[high_score['variable'] == 'Burnout'], inplace = True)
    low_score = (df.loc[df['ranks'] <= 4])

    df2 = df.loc[df['variable'] == 'Burnout', 'ranks']
    df3 = df.loc[df['variable'] == 'Attrition', 'ranks']    
#    print(df2.iloc[0])
#    if (('Burnout' in df.variable.values) and (df2.iloc[0] >= 7)):
    if (('Burnout' in df.variable.values) and (df2.iloc[0] <= 4)): 
        if DEV_MODE:   
            print('Detected Burnout')
#        low_score = low_score.append({'variable': 'Burnout'}, ignore_index=True)
        low_score.drop(low_score.index[low_score['variable'] == 'Burnout'], inplace = True)
        high_score = high_score.append({'variable': 'Burnout'}, ignore_index=True)
    if (('Burnout' in df.variable.values) and (df2.iloc[0] >= 7)):
        low_score = low_score.append({'variable': 'Burnout'}, ignore_index=True) 
    if (('Attrition' in df.variable.values) and (df3.iloc[0] <= 4)):
        if DEV_MODE:      
            print('Detected Attrition')
        low_score.drop(low_score.index[low_score['variable'] == 'Attrition'], inplace = True)
        high_score = high_score.append({'variable': 'Attrition'}, ignore_index=True)
    if (('Attrition' in df.variable.values) and (df3.iloc[0] >= 7)):
        low_score = low_score.append({'variable': 'Attrition'}, ignore_index=True)             
    list_pos = high_score['variable']
    list_neg = low_score['variable']

    return (list_pos, list_neg)
    
def calculate_emotional_health(selected_id):
# Note this calculation is identical with Emotional Well-Being implemented in appy.py dashboard
    interview_id=selected_id
    
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      ,a.std
      ,a.interview_id
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Burnout','Coping','Determined', 'Emotional Stability', 'Emotional State', 'Energy', 'Stress Control', 'Well Being')
      order by variable asc
      """.format(interview_id)

    df = dao.get_data(sql)
    #make burnout 1 - burnout so it is consistent with positive values for objectivity
    bo = df.loc[df['variable']=='Burnout', 'mean']
    df.loc[df['variable']=='Burnout', 'mean'] = 1-bo    
    names = ['A', 'B']
    total=df['mean'].sum()
    total=(total/8)
    missing = 1-total
    drive_score = []
    drive_score.append(total)
    drive_score.append(missing)
#    print('Emotional Health: ', total)    
    return total

def update_character_summary(interview_id, character_type, summary):
    columns = ["interview_id", "type", "summary"]
    dataframe = pd.DataFrame({'interview_id': [interview_id], 'type': [character_type], 'summary': [summary]})

    dao.upsert_database(dataframe,"character_summary")
    return
    
@app.get("/v1/generateSummaries/{id}")
async def process_summaries(id: str, background_tasks: BackgroundTasks):
    background_tasks.add_task(generate_all_summaries, id)
    return {"message": "Summary processing in the background"}

def generate_all_summaries(id):
    if DEV_MODE:
        print("dev mode true")
    else:
        print("dev mode false")

    psycho_traits = get_psychometrics(id)
    psycho_high_traits = psycho_traits[0]
    psycho_low_traits = psycho_traits[1]
    psycho_positive_attributes= psycho_high_traits
    psycho_negative_attributes= psycho_low_traits
    general_result = generate_happytransformer.generate_narrative(psycho_positive_attributes, psycho_negative_attributes)

    if DEV_MODE:
        print('\nPERSONALITY ANALYSIS REPORT: ',id, '\n')
        print('General Strengths:')
    if len(general_result[0]) != 0:
        summary = general_result[0]
        if DEV_MODE:
            print(summary)
        else:
            update_character_summary(id, "positive-psychometrics", summary)
    if DEV_MODE:
        print('\nGeneral Weaknesses:')
    if len(general_result[1]) != 0:
        summary = general_result[1]
        if DEV_MODE:
            print(summary)
        else:
            update_character_summary(id, "negative-psychometrics", summary)
    else:
        summary = 'This is very good.  All your traits are slightly above average or better.  You exhibit no weak traits.'
        if DEV_MODE:
            print(summary)
        else:
            update_character_summary(id, "negative-psychometrics", summary)

    soft_traits = get_softskills(id)
    high_softskill_traits = soft_traits[0]
    low_softskill_traits = soft_traits[1]
    soft_positive_attributes= high_softskill_traits
    soft_negative_attributes= low_softskill_traits
    if DEV_MODE:
        print('\nLeadership:')
    if ('Leadership' in soft_positive_attributes.values):
       leadership_result = generate_happytransformer.generate_narrative(['Leadership'],[])
       summary='Whether you are currently a leader of a team or not, you show the skills of a leader. ' + leadership_result[0]
       if DEV_MODE:
           print(summary)
       else:
           update_character_summary(id, "positive-leadership", summary)
    elif ('Leadership' in soft_negative_attributes.values):
       leadership_result = generate_happytransformer.generate_narrative([], ['Leadership'])
       summary = leadership_result[1]
       if DEV_MODE:
           print(summary)
       else:
           update_character_summary(id, "negative-leadership", summary)
    else:
       leadership_result = generate_happytransformer.generate_narrative([], ['Leadership'])
    #   print('pos-neg: ', leadership_result[1])
       summary='Though your leadership results are adequate, there is opportunity to improve them. ' + leadership_result[1]
       if DEV_MODE:
           print(summary)
       else:
           update_character_summary(id, "negative-leadership", summary)
    if DEV_MODE:
        print('\nGrowth Potential:')   
    if ('Growth Potential' in soft_positive_attributes.values):
       #print('found growth potential')
       growthpotential_result = generate_happytransformer.generate_narrative(['Growth Potential'],[])  
       summary='Growth potential is a very good quality to have. ' + growthpotential_result[0]
       if DEV_MODE: 
           print(summary)   
       else:
           update_character_summary(id, "positive-growthpotential", summary)
    elif ('Growth Potential' in soft_negative_attributes.values):
       #print('found neg growth potential')
       growthpotential_result = generate_happytransformer.generate_narrative([], ['Growth Potential'])
       summary='You can improve your growth potential. ' + growthpotential_result[1]
       if DEV_MODE:
           print(summary)   
       else:
           update_character_summary(id, "negative-growthpotential", summary)
    else:
       #print('found neg growth potential')
       growthpotential_result = generate_happytransformer.generate_narrative([], ['Growth Potential'])
       summary='Your growth potential is good, though there are things you can do to improve it. ' + growthpotential_result[1]
       if DEV_MODE:
           print(summary)   
       else:
           update_character_summary(id, "negative-growthpotential", summary) 
    if DEV_MODE:
        print('\nEmotional Health:')
    emotion_level=calculate_emotional_health(id)
    if emotion_level >= 0.5:
       #print('good emotion')
       emotional_health_result = generate_happytransformer.generate_narrative(['Emotional Health'],[])   
       summary = emotional_health_result[0]
       if DEV_MODE:
           print(summary)
       else:
           update_character_summary(id, "positive-emotional-health", summary)
    else:
       #print('not good emotion')
       emotional_health_result = generate_happytransformer.generate_narrative([], ['Emotional Health'])   
       summary = emotional_health_result[1]
       if DEV_MODE:
           print(summary)
       else:
           update_character_summary(id, "negative-emotional-health", summary)  
    return
      
@app.get("/version")
async def version():
    return json.dumps({"version":"Version 1.0.0"})

# MAIN
#id = 'AK10010041956'
#generate_all_summaries(id)


    

