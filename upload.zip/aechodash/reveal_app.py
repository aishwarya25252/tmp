import dash_bootstrap_components as dbc
import dao 
from dash import Dash, dcc, html, Input, Output
import numpy as np
import pandas as pd
import plotly.express as px 
import plotly.graph_objects as go
from flask import request
from furl import furl
import json

dashB_app = Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP],suppress_callback_exceptions=True)

server = dashB_app.server

#Id_drop = dcc.Dropdown(placeholder = 'select ID', options = {'AK10010025392': 'Elon Musk', 'AK10010069441': 'Marc Benioff', 'AK10010044969': 'Noam Chomsky (young)', 'AK10010089519': 'Lisa Su', 'AK10010008891': 'Noam Chomsky (older)', 'AK10010031283': 'Nelson Mandela', 'AK10010089387': 'Mike H.', 'AK10010077782': 'Judith J.', 'AK10010034308': 'Will N.', 'AK10010014848': 'Ann H.', 'AK10010063383': 'Adam H.', 'AK10010041956': 'Richard Feynman', 'AK10010082432': 'BD'})

DPI = 600
TW = 563 / (DPI / 2)
TH = 750 / (DPI / 2)

aecho_color_labels = {
    "very_high": "Very High"
    , "high": "High"
    , "high_moderate_borderline": "High-Moderate borderline"
    , "moderate": "Moderate"
    , "moderate_low_borderline": "Moderate-Low borderline"
    , "low": "Low"
    , "very_low": "Very Low"
}
aecho_scale = {
    0.0: "very_low",
    1.0: "very_low",
    2.0: "low",
    3.0: "low",
    4.0: "moderate",
    5.0: "moderate",
    6.0: "moderate",
    7.0: "high",
    8.0: "high",
    9.0: "very_high",
    10.0: "very_high"
}
aecho_color_scale={
'Very High':'#a70072', 
'High':'#045a97',
'High-Moderate borderline':'#097eef',
'Moderate':'#00d300',
'Moderate-Low borderline':'#ffff00',
'Low':'#fcad08',
'Very Low':'#ff0000'
}
#, style={'height':'100vh'}

@dashB_app.callback(
    Output('content', 'children'),
    Input('url', 'href'))
def _content(href: str):
    f = furl(href)
    param1= f.args['id']
#    print("PARAM=",param1)
    return html.Div(f'{param1}')   

def display_page() :
   return (
    dbc.Container([
    #title row
        html.Div([
    # represents the URL bar, doesn't render anything
        dcc.Location(id='url', refresh=False),
    # content will be rendered in this element
        html.Div(id='content',style={"visibility": "hidden"}),
       ]),
        dbc.Row([
            dbc.Col([
#            html.H1("Aecho"),
                dbc.Card([
                dbc.CardImg(src="/static/images/aecko new.png", top=True, style={'height':'70%', 'width':'70%'}),
                dbc.CardBody([
#            html.Img(src="/static/images/aecko new.png", height="90px")
                html.I("what your voice reveals", style={'color':'gray', 'font-size':'14px'})
                ], style={'padding':'0px', 'height':'50px'}),
                ], style={"width": "14rem", 'border-color':'white'},)
            ],width=6),
            dbc.Col([
#                Id_drop
            ],width=6)
        ], justify = 'center'),
        dbc.Row([
            dbc.Col([
                html.P(" ")
            ],width=12),
        ]),
        dbc.Row([              
            dbc.Col([
                html.H5("General Strengths")
            ],width=2),
            dbc.Col([
                html.Img(src="/static/images/strong.jpeg", style={'height':'90%', 'width':'28%'})
            ],width=2)
            ]),        
        dbc.Row([
            dbc.Col([
            html.Div(id='strengths')
            ],width=12),
        ]),
        dbc.Row([
            dbc.Col([
                html.P(" ")
            ],width=12),
        ]),      
        dbc.Row([
            dbc.Col([
                html.H5("General Weaknesses")
            ],width=2),
            dbc.Col([
                html.Img(src="/static/images/weak.png", style={'height':'85%', 'width':'19%'})
            ],width=2)
        ]),   
        dbc.Row([
            dbc.Col([
            html.Div(id='weaknesses')
            ],width=12),
        ]),
        dbc.Row([
            dbc.Col([
                html.P(" ")
            ],width=12),
        ]),  

        dbc.Row([
            dbc.Col([
                html.H5("Leadership")
            ],width=1),
            dbc.Col([
                html.Img(src="/static/images/leader.png", style={'height':'90%', 'width':'20%'})
            ],width={"size":2, "offset": 1})
        ]),  
        dbc.Row([
            dbc.Col([
                html.Div(id='leadership')
            ],width=12),
        ]), 
        dbc.Row([
            dbc.Col([
                html.P(" ")
            ],width=12),
        ]),  
        dbc.Row([
            dbc.Col([
                html.H5("Growth Potential")
            ],width=2),
            dbc.Col([
                html.Img(src="/static/images/growth.png", style={'height':'90%', 'width':'20%'})
            ],width={"size":2, "offset": 0})
        ]),  

        dbc.Row([
            dbc.Col([
                html.Div(id='growthpotential')
            ],width=12),
        ]),  
        dbc.Row([
            dbc.Col([
                html.P(" ")
            ],width=12),
        ]),         
        dbc.Row([
            dbc.Col([
                html.H5("Emotional Health")
            ],width=2),
            dbc.Col([
                html.Img(src="/static/images/emohealth.png", style={'height':'90%', 'width':'22%'})
            ],width={"size":2, "offset": 0})
        ]), 
        dbc.Row([
            dbc.Col([
                html.Div(id='emotionalhealth')
            ],width=12),
        ]),         
        html.Br(),
        html.Br(),                     
        html.Br(),                 
        dbc.Row([
            dbc.Col([
                 dcc.Graph(id='psych-scatter'),
            ],width=6),
            dbc.Col([
               dcc.Graph(id = 'big5'),
               dcc.Graph(id = 'big5-legend')
            ],width=6)
        ]),

        dbc.Row([
            dbc.Col([
               dcc.Graph(id = 'psych-bar')                       
            ],width=6),
            dbc.Col([
              dcc.Graph(id = 'top6'),
              dcc.Graph(id = 'top6-legend')
            ],width=6)
        ],className="h-55"),
        dbc.Row([
            dbc.Col([
              dcc.Graph(id = 'team-player')   
            ],width=4),
            dbc.Col([
              dcc.Graph(id = 'sociable')        
            ],width=4),        
            dbc.Col([
              dcc.Graph(id = 'emotional-wellbeing')            
            ],width=4)
        ],style={"height": "45%"}),  
        dbc.Row([
            dbc.Col([
              dcc.Graph(id = 'cohesion')   
            ],width=4),
            dbc.Col([
              dcc.Graph(id = 'autonomy')        
            ],width=4),        
            dbc.Col([
              dcc.Graph(id = 'subjectivity')            
            ],width=4)
        ],style={"height": "45%"}),  
    
        dbc.Row([
            dbc.Col([
              dcc.Graph(id = 'goal-drive')       
            ],width=4),
            dbc.Col([
              dcc.Graph(id = 'extrovert')            
            ],width=4),
            dbc.Col([
              dcc.Graph(id = 'depression')            
            ],width=4)
        ],style={"height": "40%"}),
        html.Br(),
        html.Br(), 
        html.Br(),
        html.Br(),
        dbc.Row([
            dbc.Col([
              dcc.Graph(id = 'sentiment')       
            ],width=4),
            dbc.Col([
              dcc.Graph(id = 'introspective')            
            ],width=4),
            dbc.Col([
#          dcc.Graph(id = 'depression')            
            ],width=4)
        ],className="h-50")            
    ],style={"height": "100vh"},)
   )

@dashB_app.callback(
    Output(component_id = 'strengths', component_property = 'children'),
    Input(component_id = 'content', component_property = 'children')
)
def strengths(selected_id):
    interview_id=json.loads(json.dumps(selected_id))['props']['children']
    sql = """
      select summary
      from character_summary a
      where a.interview_id = '{}' 
      and a.type = 'positive-psychometrics' 
      """.format(interview_id)

    df = dao.get_data(sql)

    text=df['summary']
    
    return text

@dashB_app.callback(
    Output(component_id = 'weaknesses', component_property = 'children'),
    Input('content', component_property = 'children')
)
def weaknesses(selected_id):
    interview_id=json.loads(json.dumps(selected_id))['props']['children']
    sql = """
      select summary
      from character_summary a
      where a.interview_id = '{}' 
      and a.type = 'negative-psychometrics' 
      """.format(interview_id)

    df = dao.get_data(sql)

    text=df['summary']

    return text

@dashB_app.callback(
    Output(component_id = 'leadership', component_property = 'children'),
    Input('content', component_property = 'children')
)
def leadership(selected_id):
    interview_id=json.loads(json.dumps(selected_id))['props']['children']
    sql = """
      select summary
      from character_summary a
      where a.interview_id = '{}' 
      and a.type like '%%-leadership' 
      """.format(interview_id)

    df = dao.get_data(sql)

    text=df['summary']
   
    return text   
    
@dashB_app.callback(
    Output(component_id = 'growthpotential', component_property = 'children'),
    Input('content', 'children')
)
def growthpotential(selected_id):
    interview_id=json.loads(json.dumps(selected_id))['props']['children']
    sql = """
      select summary
      from character_summary a
      where a.interview_id = '{}' 
      and a.type like '%%-growthpotential' 
      """.format(interview_id)

    df = dao.get_data(sql)

    text=df['summary']

    return text      

@dashB_app.callback(
    Output(component_id = 'emotionalhealth', component_property = 'children'),
    Input('content', 'children')
)
def emotionalhealth(selected_id):
    interview_id=json.loads(json.dumps(selected_id))['props']['children']
    sql = """
      select summary
      from character_summary a
      where a.interview_id = '{}' 
      and a.type like '%%-emotional-health' 
      """.format(interview_id)

    df = dao.get_data(sql)

    text=df['summary']
    
    return text 

@dashB_app.callback(
    Output(component_id = 'psych-scatter', component_property = 'figure'),
    Input('content', component_property = 'children')
)    
def psychometric_scatter(selected_id):
    print("inside scatter interview_id : ", selected_id)
    json_str=json.dumps(selected_id)
    resp=json.loads(json_str)
    interview_id=resp['props']['children']
    sql = """
      select Distinct               
      vmk.variable_label variable
      , a.mean 
      ,round(-1*a.std::numeric, 4) std
      ,a.ranks
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      order by a.ranks desc
      """.format(interview_id)
      
    df = dao.get_data(sql)
    freq = df.groupby(["mean", "std"]).size().to_frame("freq").values
     
    df = df.drop_duplicates().groupby(["mean", "std"])["variable"].apply(lambda v: '<br>'.join(v)).reset_index()
    df['freq'] = freq*3
    df['freqstr']=df['freq'].astype(str)
#    print(df['variable'])
    fig = px.scatter(df,x="std", y="mean", log_x=False, log_y=False, text="variable",
    size='freq',
    color= 'freqstr',
    color_discrete_sequence=px.colors.qualitative.Pastel2,   #Antique,
    hover_data={'freqstr':False, 'freq':False, 'std':True, 'mean':True},
    size_max=60
    )

    fig.update_traces(textposition='middle center', cliponaxis = False)

    fig.update_layout(
        height=400,
        width=600,
        title_text='<br><span style="font-size: 22px">  Psychometrics</span>',
        title={
            "yref": "container",
            "y" : 1,
            "yanchor" : "bottom"  
        },
        xaxis_title="variance",
        yaxis_title="intensity",
        hoverlabel=dict(
        bgcolor="rgb(124,124,124)",
        font_size=12,
        font_family="Arial"
        ),
        margin=dict(l=2, r=2, t=40, b=2),
        xaxis=dict(zeroline=False, showgrid=False),
        yaxis=dict(zeroline=False, showgrid=False),
        showlegend=False,
#        paper_bgcolor="LightSteelBlue"
        )

    fig.update_yaxes(automargin=True, title_font={"size": 12})
    fig.update_xaxes(automargin=True, title_font={"size": 12})
    fig.update_traces(textfont_size=8)
    fig.add_vline(x=-0.15, line_width=1, line_dash="dash", line_color="green")
    fig.add_hline(y=0.5, line_width=1, line_dash="dash", line_color="green")
#    display_page()
    return fig


@dashB_app.callback(
    Output(component_id = 'big5', component_property = 'figure'),
    Input(component_id = 'content', component_property = 'children')
)
def Big5(selected_id):
    interview_id=json.loads(json.dumps(selected_id))['props']['children']
    sql = "select * from interview_B56SK where interview_id = '{}' and lower(caracteristic_type) = 'personality'".format(interview_id)
    df = dao.get_data(sql)
    grouped = df.sort_values("ranks", ascending=True)
    long_table = pd.DataFrame({c: [round(v, 2)] for i, (c, v) in enumerate(grouped[["caracteristic", "ranks"]].values)})

#    values = grouped.ranks.values
    values = df.ranks.values
    colors = [aecho_color_labels.get(aecho_scale.get(np.floor(v))) for v in values]
 
    defbig=[
        "Diligent, thorough, careful, responsible, persistent, organized, obligated, self-disciplined",
        "Energetic, active, outgoing, expressive, socially engaged", 
        "Getting along with others, considerate, trustworthy, and compromising", 
        "Open to new experiences, art, emotions, adventure, unusual ideas, imaginative, and curious", 
        "Tendency to cope well, better handle stress, be stable at job and personal life"
        ]
    df['def']=defbig
        
    fig = px.bar(df,color=colors, color_discrete_map=aecho_color_scale, 
        log_x=False,log_y=False, 
        orientation='h', x="ranks", y="caracteristic", 
        text=df['ranks'].round(1),
        custom_data=[df['def']])
    fig.update_layout(
        margin=dict(l=2, r=2, t=40, b=2),
        title={
            "yref": "container",
            "y" : 1,
            "yanchor" : "bottom"  
        },        
        font_family="Helvetica",
        height = 380, #400
        paper_bgcolor="white",
        title_text='<br><span style="font-size: 22px">  Big 5 Personality</span>',
        title_x=0.15,
        width = 630, #700
        xaxis_title=None,
        yaxis_title=None
    )
#    print("user_defined hovertemplate:", fig.data[0].hovertemplate)
#    print(df)

    htext="%{customdata[0]} "
    fig.update_traces(width=.5)
    fig.update_traces(showlegend=False, hovertemplate=htext)
    fig.update_xaxes(range=[0, 10])

    return fig

@dashB_app.callback(
    Output(component_id= 'big5-legend', component_property= 'figure'),
    Input(component_id='content', component_property= 'children')
)
def Big5_legend(selected_id):
    interview_id=json.loads(json.dumps(selected_id))['props']['children']
    sql = "select * from interview_B56SK where interview_id = '{}' and lower(caracteristic_type) = 'personality'".format(interview_id)
    df = dao.get_data(sql)
    grouped = df.sort_values("ranks", ascending=False)
    long_table = pd.DataFrame({c: [round(v, 2)] for i, (c, v ) in enumerate(grouped[["caracteristic", "ranks"]].values)})

    values = grouped.ranks.values
    colors = [aecho_color_labels.get(aecho_scale.get(np.floor(v))) for v in values]

    
    fig = px.bar(grouped, color=colors, color_discrete_map=aecho_color_scale, log_x=False, log_y=False, orientation='h', x="ranks", y='caracteristic')
    fig.update_layout(
        font_family="Helvetica",
        height = 100,
        paper_bgcolor = 'rgba(0,0,0,0)',
        plot_bgcolor = 'rgba(0,0,0,0)',
        title_text='',
        width=350,
        xaxis_title=None,
        yaxis_title=None
    )
    fig.update_layout(legend=dict(
        orientation = 'h',
        yanchor="bottom",
        y=1.0,
        xanchor="right",
        x=1.5
    ))
    fig.update_traces(visible="legendonly")
    fig.update_xaxes(showgrid=False, zeroline=False, visible=False)
    fig.update_yaxes(showgrid=False, visible = False, zeroline=False)
    return fig
    
@dashB_app.callback(
    Output(component_id = 'psych-bar', component_property = 'figure'),
    Input('content', 'children')
)
def psychometric_bar(selected_id):
    
    interview_id=json.loads(json.dumps(selected_id))['props']['children']
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      ,a.std
      ,a.interview_id
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      order by variable asc
      """.format(interview_id)
      
    df = dao.get_data(sql)
#    fig = px.bar(df, x='variable', y='mean', error_y='std', barmode='group', color='mean')
    fig = px.bar(df, x='variable', y='mean', barmode='group', color='mean')
    fig.update_traces(width=0.3)

    fig.update_layout (
        title_text='<br><span style="font-size: 22px">  Average Trait Intensity</span>',
        title={
            "yref": "container",
            "y" : 1,
            "yanchor" : "bottom"  
        },
        xaxis_title="traits",
        yaxis_title="intensity",
   #    legend_title="public figures",
        margin=dict(l=2, r=2, t=40, b=2),
        xaxis = dict(tickfont = dict(size=8))
    )

    fig.update_xaxes(
    #    showgrid=True,
        tickangle =45,
        ticks="outside",
        tickson="boundaries",
        ticklen=10
    )

    htext="%{x}<br>%{y:.1%}"
    fig.update_traces(hovertemplate=htext)
    fig.update_layout(showlegend=False)
    
    return fig

@dashB_app.callback(
    Output(component_id = 'top6', component_property = 'figure'),
    Input('content', 'children')
)
def Top6(selected_id):
    interview_id=json.loads(json.dumps(selected_id))['props']['children']
    sql = "select * from interview_B56SK where interview_id = '{}' and lower(caracteristic_type) = 'soft skill'".format(interview_id)
    df = dao.get_data(sql)
    grouped = df.sort_values("ranks", ascending=True)
    long_table = pd.DataFrame({c: [round(v, 2)] for i, (c, v) in enumerate(grouped[["caracteristic", "ranks"]].values)})

#    values = grouped.ranks.values
    values = df.ranks.values    
    colors = [aecho_color_labels.get(aecho_scale.get(np.floor(v))) for v in values]
    defsoft=[
        "Able to work in new environments, learn new skills and adjust to changes",
        "Includes different types of diversity; different perspectives, experiences, and competencies", 
        "Skills developed between individuals and teams in order to interact, engage, and synergize", 
        "Determines whether you can make important decisions and manage situations and other people", 
        "Potential to cultivate inner potentialities, seek out optimal challenges,<br> and integrate new experiences",
        "Ability to work on things in the right order"]
    df['def']=defsoft
            
    fig = px.bar(df,color=colors, color_discrete_map=aecho_color_scale, 
        log_x=False,log_y=False, 
        orientation='h', x="ranks", y="caracteristic",
        text=df['ranks'].round(1),
        custom_data=[df['def']])

    fig.update_layout(
        margin=dict(l=2, r=2, t=40, b=2),
        title={
            "yref": "container",
            "y" : 1,
            "yanchor" : "bottom"  
        },            
        font_family="Helvetica",
        height = 380, #400
        paper_bgcolor="white",
        title_text='<br><span style="font-size: 22px">  Top 6 Soft Skills</span>',
        title_x=0.12,        
        width = 630, #700
        xaxis_title=None,
        yaxis_title=None
    )
    htext="%{customdata[0]} "
    fig.update_traces(width=.5)
    fig.update_traces(showlegend=False, hovertemplate=htext)
    fig.update_xaxes(range=[0, 10])

    return fig
    
@dashB_app.callback(
    Output(component_id= 'top6-legend', component_property= 'figure'),
    Input('content', 'children')
)
def Top6_legend(selected_id):
    interview_id=json.loads(json.dumps(selected_id))['props']['children']
    sql = "select * from interview_B56SK where interview_id = '{}' and lower(caracteristic_type) = 'personality'".format(interview_id)
    df = dao.get_data(sql)
    grouped = df.sort_values("ranks", ascending=False)
    long_table = pd.DataFrame({c: [round(v, 2)] for i, (c, v ) in enumerate(grouped[["caracteristic", "ranks"]].values)})

    values = grouped.ranks.values
    colors = [aecho_color_labels.get(aecho_scale.get(np.floor(v))) for v in values]

    
    fig = px.bar(grouped, color=colors, color_discrete_map=aecho_color_scale, log_x=False, log_y=False, orientation='h', x="ranks", y='caracteristic')
    fig.update_layout(
        font_family="Helvetica",
        height = 100,
        paper_bgcolor = 'rgba(0,0,0,0)',
        plot_bgcolor = 'rgba(0,0,0,0)',
        title_text='',
        width=350,
        xaxis_title=None,
        yaxis_title=None
    )
    fig.update_layout(legend=dict(
        orientation = 'h',
        yanchor="bottom",
        y=1.0,
        xanchor="right",
        x=1.5
    ))
    fig.update_traces(visible="legendonly")
    fig.update_xaxes(showgrid=False, zeroline=False, visible=False)
    fig.update_yaxes(showgrid=False, visible = False, zeroline=False)

    return fig
    
@dashB_app.callback(
    Output(component_id = 'team-player', component_property = 'figure'),
    Input('content', 'children')
)
def team_player(selected_id):
    
    interview_id=json.loads(json.dumps(selected_id))['props']['children']
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      ,a.std
      ,a.interview_id
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Adaptive','Adjustment','Communicative', 'Conscientiousness', 'Cooperation', 'Dependable', 'Engaged', 'Integrity', 'Loyalty', 'Openness', 'Social Skills')
      order by variable asc
      """.format(interview_id)

    df = dao.get_data(sql)
    names = ['A', 'B']
    total=df['mean'].sum()
    total=(total/11)
    missing = 1-total
    drive_score = []
    drive_score.append(total)
    drive_score.append(missing)
    colors = {'A':'#550300', 'B':'#339922'}

#    fig = px.pie(values=drive_score, names=names, title="Team Player Score", color=names, color_discrete_map={'A':'green', 'B':'lightgray'}, hole=.5)
    fig = px.pie(values=drive_score, names=names, color=names, color_discrete_map={'A':'green', 'B':'lightgray'}, hole=.5)    
    fig.update_layout(
        annotations=[
            # Set 'showarrow' to 'False' to turn off the label indicator
            dict(text="{:.1%}".format(total), x=0.5, y=0.5, font_size=16, showarrow=False),
        ],
        margin=dict(t=120, b=220, l=120, r=120),
        showlegend=False,
        title_x=0.5,
        title={
          'text': "Team Player Score",
          'y':0.8, #0.7
          'x':0.5,
          'xanchor': 'center',
          'yanchor': 'top'
        }
    )
    ts= "%{value:.1%}"
    if (total < 0.5): htext = "Your score as a team player is somewhat low"
    elif (total >= 0.5 and total < 0.6): htext = "You are considered a reasonably good team player"
    elif (total >=0.6 and total < 0.7): htext="Consider yourself a very good team player"
    else : htext ="You are an outstanding team player"

    fig.update_traces(textinfo='none', hovertemplate=htext)
    dcc.Dropdown(
        multi=False
    )
    
    return fig

@dashB_app.callback(
    Output(component_id = 'sociable', component_property = 'figure'),
    Input('content', 'children')
)
def socialable(selected_id):
    
    interview_id=json.loads(json.dumps(selected_id))['props']['children']
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      ,a.std
      ,a.interview_id
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Attentive','Communication','Communicative', 'Cooperation', 'Energy', 'Extraversion', 'Sales Skills', 'Social', 'Social Skills', 'Temperament')
      order by variable asc
      """.format(interview_id)

    df = dao.get_data(sql)
    names = ['A', 'B']
    total=df['mean'].sum()
    total=(total/10)
    missing = 1-total
    drive_score = []
    drive_score.append(total)
    drive_score.append(missing)

    fig = px.pie(values=drive_score, names=names, color=names, color_discrete_map={'A':'yellow', 'B':'lightgray'}, hole=.5)
    fig.update_layout(
        annotations=[
            # Set 'showarrow' to 'False' to turn off the label indicator
            dict(text="{:.1%}".format(total), x=0.5, y=0.5, font_size=18, showarrow=False),
        ],
        margin=dict(t=120, b=220, l=120, r=120),
        showlegend=False,
        title_x=0.5,
        title={
          'text': "Sociable level",
          'y':0.8,
          'x':0.5,
          'xanchor': 'center',
          'yanchor': 'top'
        }        
    )
    if (total < 0.5): htext = "Your sociable score is somewhat low"
    elif (total >= 0.5 and total < 0.6): htext = "This is considered a good sociable score"
    elif (total >=0.6 and total < 0.7): htext="This is a very good sociable score"
    else : htext ="You are exceptionally sociable"

    fig.update_traces(textinfo='none', hovertemplate=htext)    
    dcc.Dropdown(
        multi=False
    )
    
    return fig
    
@dashB_app.callback(
    Output(component_id = 'emotional-wellbeing', component_property = 'figure'),
    Input('content', 'children')
)
def emotional_wellbeing(selected_id):
    
    interview_id=json.loads(json.dumps(selected_id))['props']['children']
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      ,a.std
      ,a.interview_id
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Burnout','Coping','Determined', 'Emotional Stability', 'Emotional State', 'Energy', 'Stress Control', 'Well Being')
      order by variable asc
      """.format(interview_id)

    df = dao.get_data(sql)
    #make burnout 1 - burnout so it is consistent with positive values for objectivity
    bo = df.loc[df['variable']=='Burnout', 'mean']
    df.loc[df['variable']=='Burnout', 'mean'] = 1-bo    
    names = ['A', 'B']
    total=df['mean'].sum()
    total=(total/8)
    missing = 1-total
    drive_score = []
    drive_score.append(total)
    drive_score.append(missing)
#    print(drive_score)
    fig = px.pie(values=drive_score, names=names, color=names, color_discrete_map={'A':'purple', 'B':'lightgray'}, hole=.5)
    fig.update_layout(
        annotations=[
            # Set 'showarrow' to 'False' to turn off the label indicator
            dict(text="{:.1%}".format(total), x=0.5, y=0.5, font_size=18, showarrow=False),
        ],
        margin=dict(t=120, b=220, l=120, r=120),
        showlegend=False,
        title_x=0.5,
        title={
        'text': "Emotional Well-being",
          'y':0.8,
          'x':0.5,
          'xanchor': 'center',
          'yanchor': 'top'
        }
    )
    if (total < 0.5): htext = "Your emotional well-being is considered low"
    elif (total >= 0.5 and total < 0.6): htext = "Your emotional well-being is okay"
    elif (total >=0.6 and total < 0.7): htext="You have a very emotional well-being"
    else : htext ="Your emotional well-being is exceptionally good"

    fig.update_traces(textinfo='none', hovertemplate=htext)    
    
    return fig    

@dashB_app.callback(
    Output(component_id = 'cohesion', component_property = 'figure'),
    Input('content', 'children')
)
def cohesion(selected_id):
    
    interview_id=json.loads(json.dumps(selected_id))['props']['children']
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      ,a.std
      ,a.interview_id
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Attitude','Communication','Communicative', 'Conscientiousness', 'Cooperation', 'Creative-Thinker', 'Emotional Stability', 'Engaged', 'Extraversion', 'Openness', 'Social', 'Social Skills', 'Well Being')
      order by variable asc
      """.format(interview_id)

    df = dao.get_data(sql)
    names = ['A', 'B']
    total=df['mean'].sum()
    total=(total/13)
    missing = 1-total
    drive_score = []
    drive_score.append(total)
    drive_score.append(missing)
    colors = {'A':'#550300', 'B':'#339922'}

    fig = px.pie(values=drive_score, names=names, title="Cohesion Score", color=names, color_discrete_map={'A':'green', 'B':'lightgray'}, hole=.5)
    fig.update_layout(
        annotations=[
            # Set 'showarrow' to 'False' to turn off the label indicator
            dict(text="{:.1%}".format(total), x=0.5, y=0.5, font_size=18, showarrow=False),
        ],
        margin=dict(t=120, b=220, l=120, r=120),
        showlegend=False,
        title_x=0.5,
        title={
        'text': "Cohesion Score",
          'y':0.8,
          'x':0.5,
          'xanchor': 'center',
          'yanchor': 'top'
        }
    )
    if (total < 0.5): htext = "Your interaction with others is somewhat low"
    elif (total >= 0.5 and total < 0.6): htext = "You have reasonably good interaction with others"
    elif (total >=0.6 and total < 0.7): htext="Your interaction with others is very good"
    else : htext ="You relate to others extremely well"

    fig.update_traces(textinfo='none', hovertemplate=htext)    
    fig.update_traces(textinfo='none')
    
    return fig

@dashB_app.callback(
    Output(component_id = 'autonomy', component_property = 'figure'),
    Input('content', 'children')
)
def autonomy(selected_id):
    
    interview_id=json.loads(json.dumps(selected_id))['props']['children']
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      ,a.std
      ,a.interview_id
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Adaptive', 'Adjustment', 'Attentive', 'Attitude','Creative-Artistically','Creative-Thinker', 'Determined', 'Energy', 'Openness', 'Stress Control', 'Temperament')
      order by variable asc
      """.format(interview_id)

    df = dao.get_data(sql)
    names = ['A', 'B']
    total=df['mean'].sum()
    total=(total/11)
    missing = 1-total
    drive_score = []
    drive_score.append(total)
    drive_score.append(missing)
    colors = {'A':'#550300', 'B':'#339922'}

    fig = px.pie(values=drive_score, names=names, color=names, color_discrete_map={'A':'darkgreen', 'B':'lightgray'}, hole=.5)
    fig.update_layout(
        annotations=[
            # Set 'showarrow' to 'False' to turn off the label indicator
            dict(text="{:.1%}".format(total), x=0.5, y=0.5, font_size=18, showarrow=False),
        ],
        margin=dict(t=120, b=220, l=120, r=120),
        showlegend=False,
        title_x=0.5,
        title={
        'text': "Autonomy",
          'y':0.8,
          'x':0.5,
          'xanchor': 'center',
          'yanchor': 'top'
        }
    )
    if (total < 0.5): htext = "Low reflective awareness of personal desires, wishes and intentions"
    elif (total >= 0.5 and total < 0.6): htext = "You show a good level of reflective awareness and autonomy"
    elif (total >=0.6 and total < 0.7): htext="You are reflective and aware of your desires and intentions"
    else : htext ="You posses an outstanding awareness of your desires and intentions"

    fig.update_traces(textinfo='none', hovertemplate=htext)    
    
    return fig

@dashB_app.callback(
    Output(component_id = 'subjectivity', component_property = 'figure'),
    Input('content', 'children')
)
def subjectivity(selected_id):
    
    interview_id=json.loads(json.dumps(selected_id))['props']['children']
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      ,a.std
      ,a.interview_id
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Adjustment', 'Burnout', 'Communication','Conscientiousness','Dependable', 'Emotional Stability', 'Emotional State', 'Learning', 'Temperament')
      order by variable asc
      """.format(interview_id)

    df = dao.get_data(sql)
#    print(df[['variable','mean']])
    #make burnout 1 - burnout so it is consistent with positive values for objectivity
    bo = df.loc[df['variable']=='Burnout', 'mean']
    df.loc[df['variable']=='Burnout', 'mean'] = 1-bo
    print(df.loc[df['variable']=='Burnout', 'mean'])

    names = ['A', 'B']
    total=df['mean'].sum()
    total=(total/9)
    #missing and total represent objectivity therefore flip for subjectivity
    total = 1 - total
    
    missing = 1-total
    drive_score = []
    drive_score.append(total)
    drive_score.append(missing)
    colors = {'A':'#550300', 'B':'#339922'}

    fig = px.pie(values=drive_score, names=names, color=names, color_discrete_map={'A':'brown', 'B':'lightgray'}, hole=.5)
    fig.update_layout(
        annotations=[
            # Set 'showarrow' to 'False' to turn off the label indicator
            dict(text="{:.1%}".format(total), x=0.5, y=0.5, font_size=18, showarrow=False),
        ],
        margin=dict(t=120, b=220, l=120, r=120),
        showlegend=False,
        title_x=0.5,
        title={
        'text': "Subjectivity",
          'y':0.8,
          'x':0.5,
          'xanchor': 'center',
          'yanchor': 'top'
        }
    )

    if (total < 0.5): htext = "You tend to interpret data or make judgments objectively, based on facts"
    elif (total >= 0.5 and total < 0.6): htext = "Interpretation of data is moderately influenced by experiences"
    elif (total >=0.6 and total < 0.7): htext="Strong tendency to make judgments based on beliefs, or experiences"
    else : htext ="Tendency to interpret data is extremely influenced by personal feelings, beliefs, or experiences "

    fig.update_traces(textinfo='none', hovertemplate=htext)    
    
    return fig

@dashB_app.callback(
    Output(component_id = 'goal-drive', component_property = 'figure'),
    Input('content', 'children')
)
def goal_drive(selected_id):
    
    interview_id=json.loads(json.dumps(selected_id))['props']['children']
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      ,a.std
      ,a.interview_id
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Ambition','Determined','Engaged', 'Opportunistic')
      order by variable asc
      """.format(interview_id)

#      and vmk.variable = "Determined"          
    df = dao.get_data(sql)
    names = ['A', 'B']
    total=df['mean'].sum()
    total=(total/4)
    missing = 1-total
    drive_score = []
    drive_score.append(total)
    drive_score.append(missing)
    colors = {'A':'#550300', 'B':'#339922'}

    fig = px.pie(values=drive_score, names=names, color=names, color_discrete_map={'A':'lightred', 'B':'lightgray'}, hole=.5)
    fig.update_layout(
        annotations=[
            # Set 'showarrow' to 'False' to turn off the label indicator
            dict(text="{:.1%}".format(total), x=0.5, y=0.5, font_size=18, showarrow=False),
        ],
        margin=dict(t=120, b=220, l=120, r=120),
        showlegend=False,
        title_x=0.5,
        title={
          'text': "Goal Driven Score",
          'y':0.8,
          'x':0.5,
          'xanchor': 'center',
          'yanchor': 'top'
        }
    )
    if (total < 0.5): htext = "Your drive to achieve goals is not strong"
    elif (total >= 0.5 and total < 0.6): htext = "You are goal driven"
    elif (total >=0.6 and total < 0.7): htext="You have a strong drive to achieve goals"
    else : htext ="You are exceptionally goal driven"

    fig.update_traces(textinfo='none', hovertemplate=htext)    

    return fig

@dashB_app.callback(
    Output(component_id = 'extrovert', component_property = 'figure'),
    Input('content', 'children')
)
def extrovert(selected_id):
    
    interview_id=json.loads(json.dumps(selected_id))['props']['children']
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      ,a.std
      ,a.interview_id
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Communication','Communicative','Emotional State', 'Openness', 'Extraversion', 'Openness', 'Social', 'Social Skills')
      order by variable asc
      """.format(interview_id)

    df = dao.get_data(sql)
    names = ['A', 'B']
    total=df['mean'].sum()
    total=(total/8)
    missing = 1-total
    drive_score = []
    drive_score.append(total)
    drive_score.append(missing)

    fig = px.pie(values=drive_score, names=names, title="Extrovert", color=names, color_discrete_map={'A':'lightgreen', 'B':'lightgray'}, hole=.5)
    fig.update_layout(
        annotations=[
            # Set 'showarrow' to 'False' to turn off the label indicator
            dict(text="{:.1%}".format(total), x=0.5, y=0.5, font_size=18, showarrow=False),
        ],
        margin=dict(t=120, b=220, l=120, r=120),
        showlegend=False,
        title_x=0.5,
        title={
          'text': "Extrovert",        
          'y':0.8,
          'x':0.5,
          'xanchor': 'center',
          'yanchor': 'top'
        }
    )
    if (total < 0.4): htext = "Indicates you are not an extrovert"
    elif (total >= 0.4 and total < 0.6): htext = "You are considered to be both an extrovert and an introvert"
    elif (total >=0.6 and total < 0.7): htext="This indicates you seek gratification from outside"
    else : htext ="You are likely warm, positive, gregarious and seek excitement"

    fig.update_traces(textinfo='none', hovertemplate=htext)    

    return fig        

@dashB_app.callback(
    Output(component_id = 'depression', component_property = 'figure'),
    Input('content', 'children')
)
def depression(selected_id):
    
    interview_id=json.loads(json.dumps(selected_id))['props']['children']
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      ,a.std
      ,a.interview_id
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Burnout', 'Coping','Emotional Stability','Emotional State', 'Energy', 'Satisfaction', 'Stress Control', 'Well Being')
      order by variable asc
      """.format(interview_id)

    df = dao.get_data(sql)
    #make burnout 1 - burnout so it is consistent with positive values for objectivity
    bo = df.loc[df['variable']=='Burnout', 'mean']
    df.loc[df['variable']=='Burnout', 'mean'] = 1-bo
    names = ['A', 'B']
    total=df['mean'].sum()
    total=(total/8)
    #missing and total represent objectivity therefore flip for depression
#    total = 1 - total
    
    missing = 1-total
    drive_score = []
    drive_score.append(total)
    drive_score.append(missing)

    fig = px.pie(values=drive_score, names=names, color=names, color_discrete_map={'A':'magenta', 'B':'lightgray'}, hole=.5)
    fig.update_layout(
        paper_bgcolor="white",
        annotations=[
            # Set 'showarrow' to 'False' to turn off the label indicator
            dict(text="{:.1%}".format(total), x=0.5, y=0.5, font_size=18, showarrow=False),
        ],
        margin=dict(t=120, b=220, l=120, r=120),
        showlegend=False,
        title_x=0.5,
        title={
          'text': "Positive Mood",                
          'y':0.8,
          'x':0.5,
          'xanchor': 'center',
          'yanchor': 'top'
        }
    )
    if (total < 0.3): htext = "This shows concerning levels of melancholy or depression"
    elif (total >= 0.3 and total < 0.4): htext = "Indicates sadness or melancholy"
    elif (total >=0.4 and total < 0.5): htext="indicates moderate mood levels"
    elif (total >=0.5 and total < 0.6): htext="indicates positive mood levels"
    else : htext ="This indicates very positive mood levels"

    fig.update_traces(textinfo='none', hovertemplate=htext)    

    return fig        
    
@dashB_app.callback(
    Output(component_id = 'sentiment', component_property = 'figure'),
    Input('content', 'children')
)
def sentiment(selected_id):
    
    interview_id=json.loads(json.dumps(selected_id))['props']['children']
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      ,a.std
      ,a.interview_id
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Attitude', 'Emotional Stability','Emotional State', 'Energy', 'Engaged', 'Satisfaction', 'Social', 'Stress Control', 'Well Being')
      order by variable asc
      """.format(interview_id)

    df = dao.get_data(sql)
#    names = ['A', 'B']
    total=df['mean'].sum()
    total=(total/9)
    missing = 1-total

    drive_score = []
    drive_score.append(total)
    drive_score.append(missing)

    names_col = ['Count', 'dummy']
    pak_data = pd.DataFrame([[total, 0],[missing, 0]],columns=names_col)    

    fig = px.bar(pak_data, x='dummy', y='Count', barmode='stack', title='Overall Sentiment')
    
    fig.update_layout(
        font_family="Arial",
        font_size=14,
        height = 300,
        paper_bgcolor="white",
        width = 220,  #200
        title_x=1.0,
        annotations=[
            # Set 'showarrow' to 'False' to turn off the label indicator
            dict(text="{:.1%}".format(total), x=1.4, y=0.5, font_size=18, showarrow=False),
        ],
        margin=dict(t=30, b=120, l=140, r=0),
        xaxis_title=None,
        yaxis_title=None,
        plot_bgcolor='rgba(0,0,0,0)'
    )
    htext= "<span>A 0 indicates low sentiment<br> and 1 high sentiment</span>"
    fig.update_traces(marker_color=['#636EFA','lightgray'])
    fig.update_traces(width=2.4)
    fig.update_traces(showlegend=False, hovertemplate=htext)
    fig.update_yaxes(range=[0, 1], tick0=0, dtick=.1, tickfont=dict(size=8))
    fig.update_xaxes(showticklabels=False)
    fig.update_annotations(xanchor='left')
    
    return fig  

@dashB_app.callback(
    Output(component_id = 'introspective', component_property = 'figure'),
    Input('content', 'children')
)
def introspective(selected_id):
    
    interview_id=json.loads(json.dumps(selected_id))['props']['children']
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      ,a.std
      ,a.interview_id
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Communication', 'Communicative','Cooperation', 'Emotional State', 'Extraversion', 'Openness', 'Social', 'Stress Control')
      order by variable asc
      """.format(interview_id)

    df = dao.get_data(sql)
    #extraversion, social skills, social are inverese factors on introspection
    ex = df.loc[df['variable']=='Extraversion', 'mean']
    df.loc[df['variable']=='Extraversion', 'mean'] = 1-ex
    sc = df.loc[df['variable']=='Social', 'mean']
    df.loc[df['variable']=='Social', 'mean'] = 1-sc
    scsk = df.loc[df['variable']=='Social Skills', 'mean']
    df.loc[df['variable']=='Social Skills', 'mean'] = 1-scsk
    total=df['mean'].sum()
    total=(total/8)
    missing = 1-total

    drive_score = []
    drive_score.append(total)
    drive_score.append(missing)

    names_col = ['Count', 'dummy']
    pak_data = pd.DataFrame([[total, 0],[missing, 0]],columns=names_col)    

    fig = px.bar(pak_data, x='dummy', y='Count', barmode='stack', title='Introspective')
    
    fig.update_layout(
        font_family="Arial",
        font_size=14,
        height = 300,
        paper_bgcolor="white",
        width = 220,  #200
        title_x=1.0,
        annotations=[
            # Set 'showarrow' to 'False' to turn off the label indicator
            dict(text="{:.1%}".format(total), x=1.4, y=0.5, font_size=18, showarrow=False),
        ],
        margin=dict(t=30, b=120, l=140, r=0),
        xaxis_title=None,
        yaxis_title=None,
        plot_bgcolor='rgba(0,0,0,0)'
    )
    htext= "<span>Shows the degree in which<br> you look inward</span>"
    fig.update_traces(marker_color=['violet','lightgray'])
    fig.update_traces(width=2.4)
    fig.update_traces(showlegend=False, hovertemplate=htext)
    fig.update_yaxes(range=[0, 1], tick0=0, dtick=.1, tickfont=dict(size=8))
    fig.update_xaxes(showticklabels=False)
    fig.update_annotations(xanchor='left')
    
    return fig        
    
    
if __name__ == '__main__':
    dashB_app.layout = display_page
    dashB_app.run_server(debug=True, port=8000, host='0.0.0.0')

