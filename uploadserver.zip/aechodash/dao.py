import psycopg2
import sqlalchemy
from sqlalchemy import event


from sqlalchemy import Table
from sqlalchemy.engine.base import Engine as sql_engine
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.automap import automap_base
import pandas as pd

#hyper parameter to make it possible to test everything locally

LOCAL = False

conn_config = {
    "local_host": "127.0.0.1",
    "host"      : "dev-db001.c6djbcgzscli.us-east-1.rds.amazonaws.com",
    "port"      : "5432",
    "database"  : "aechodeva1",
    "user"      : "AechoDevMaster",
    "password"  : "YtRg7K4$12L9&wq",
    "local"     : LOCAL #this value will make the program to read/write the DB from local host or S3 server
}
if conn_config["local"]:
    conn_config["user"] = "aechodevmaster"

#postgresql+psycopg2://:@:/?sslmode=require

def get_engine():
    if conn_config["local"]:
        connect = "postgresql+psycopg2://{}:{}@{}:{}/{}?sslmode=require".format(
            conn_config['user']
            , conn_config['password']
            , conn_config['local_host']
            , conn_config["port"]
            , conn_config['database']
        )
    else:
        connect = "postgresql+psycopg2://{}:{}@{}:{}/{}?sslmode=require".format(
            conn_config['user']
            ,conn_config['password']
            ,conn_config['host']
            ,conn_config["port"]
            ,conn_config['database']
        )

    engine = sqlalchemy.create_engine(connect)
    return engine

def write(dataset,table):
    """
        function to write information from app to database
    """
    engine = get_engine()
    dataset.to_sql(table, con=engine, index=False, if_exists="append", schema="public")



def upsert_database(dataset: pd.DataFrame, table: str, schema: str = "public") -> None:

    if len(dataset) == 0:
        return None

    flattened_input = dataset.to_dict('records')

    engine = get_engine()
    with engine.connect() as conn:
        base = automap_base()
        base.prepare(engine, reflect=True, schema=schema)
        target_table = Table(table, base.metadata,autoload=True, autoload_with=engine, schema=schema)
        chunks = [flattened_input[i:i + 200] for i in range(0, len(flattened_input), 200)]
        for chunk in chunks:
            stmt = insert(target_table).values(chunk)
            update_dict = {c.name: c for c in stmt.excluded if not c.primary_key}
            conn.execute(stmt.on_conflict_do_update(constraint=f'{table}_pkey',set_=update_dict))


def get_data(sql):
    engine = get_engine()
    df = pd.read_sql_query(sql,engine)
    return df
