import dao
import json
import numpy as np
import pandas as pd
from fastapi import FastAPI, BackgroundTasks,Request
from fastapi.responses import FileResponse, StreamingResponse

app = FastAPI()

@app.get("/")
async def root():
    return {"message": "Hello World"}

@app.get("/version")
async def version():
    return json.dumps({"version":"Version 1.0.0"})

@app.get("/v1/recordings/{selected_id}/big5")
async def Big5(selected_id):
    sql = "select * from interview_B56SK where interview_id = '{}' and lower(caracteristic_type) = 'personality'".format(selected_id)
    df = dao.get_data(sql)
    df['ranks'] = df['ranks'].round(decimals=2)
    grouped = df.sort_values("ranks", ascending=True)
    grouped = grouped.loc[:,['caracteristic', 'ranks']]
#    print(grouped)
    grouped = grouped.rename(columns={'ranks': 'big5'})
    Data = pd.DataFrame(grouped.set_index('caracteristic')).to_json()
    ranks = json.loads(Data)
#    print(ranks)
    return(ranks)

@app.get("/v1/recordings/{selected_id}/top6")
async def Top6(selected_id):
    sql = "select * from interview_B56SK where interview_id = '{}' and lower(caracteristic_type) = 'soft skill'".format(selected_id)
    df = dao.get_data(sql)
    df['ranks'] = df['ranks'].round(decimals=2)
    grouped = df.sort_values("ranks", ascending=True)
    grouped = grouped.loc[:,['caracteristic', 'ranks']]
    grouped = grouped.rename(columns={'ranks': 'top6'})
    Data = pd.DataFrame(grouped.set_index('caracteristic')).to_json()
    ranks = json.loads(Data)
    return ranks
    
def Psychometrics(selected_id):
    interview_id=selected_id
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      order by variable asc
      """.format(interview_id)
      
    df = dao.get_data(sql)
    df['mean'] = df['mean'].round(decimals=2)
    df = df.rename(columns={'mean': 'mean_intensity'})
    Data = pd.DataFrame(df.set_index('variable')).to_json()
    means = json.loads(Data)
    return means

@app.get("/v1/recordings/{selected_id}/socialTraits")    
async def SocialTraits(selected_id):
    interview_id=selected_id
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Agreeableness', 'Cooperation', 'Extraversion', 'Social')
      order by variable asc
      """.format(interview_id)
      
    df = dao.get_data(sql)
    df['mean'] = df['mean'].round(decimals=2)
    df = df.rename(columns={'mean': 'social_traits'})
    Data = pd.DataFrame(df.set_index('variable')).to_json()
    means = json.loads(Data)
    return means    

@app.get("/v1/recordings/{selected_id}/personalityTraits") 
async def PersonalityTraits(selected_id):
    interview_id=selected_id
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Adaptive', 'Adjustment', 'Ambition', 'Attentive', 'Communicative', 'Conscientiousness', 'Dependable', 'Determined', 'Engaged', 'Integrity', 'Learning', 'Loyalty', 'Openness', 'Opportunistic', 'Ordered', 'Systematic', 'Temperament')
      order by variable asc
      """.format(interview_id)
      
    df = dao.get_data(sql)
    df['mean'] = df['mean'].round(decimals=2)
    df = df.rename(columns={'mean': 'personality_traits'})
    Data = pd.DataFrame(df.set_index('variable')).to_json()
    means = json.loads(Data)
    return means 

@app.get("/v1/recordings/{selected_id}/performanceTraits") 
async def PerformanceTraits(selected_id):
    interview_id=selected_id
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Attrition', 'Creative-Artistically', 'Creative-Thinker', 'Management Skills', 'Sales Skills', 'Social Skills', 'Technical Skills')
      order by variable asc
      """.format(interview_id)
      
    df = dao.get_data(sql)
    df['mean'] = df['mean'].round(decimals=2)
    df = df.rename(columns={'mean': 'performance_traits'})
    Data = pd.DataFrame(df.set_index('variable')).to_json()
    means = json.loads(Data)
    return means    

@app.get("/v1/recordings/{selected_id}/emotionalHealthTraits")     
async def EmotionalHealthTraits(selected_id):
    interview_id=selected_id
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Burnout', 'Coping', 'Emotional Stability', 'Emotional State', 'Energy', 'Stress Control', 'Well Being')
      order by variable asc
      """.format(interview_id)
      
    df = dao.get_data(sql)
    df['mean'] = df['mean'].round(decimals=2)
    df = df.rename(columns={'mean': 'emotional_health_traits'})
    Data = pd.DataFrame(df.set_index('variable')).to_json()
    means = json.loads(Data)
    return means    

@app.get("/v1/recordings/{selected_id}/teamPlayerScore")         
async def team_player(selected_id):
    interview_id=selected_id
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      ,a.std
      ,a.interview_id
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Adaptive','Adjustment','Communicative', 'Conscientiousness', 'Cooperation', 'Dependable', 'Engaged', 'Integrity', 'Loyalty', 'Openness', 'Social Skills')
      order by variable asc
      """.format(interview_id)

    df = dao.get_data(sql)
    total=df['mean'].sum()
    total=(total/11).round(decimals=3)
    missing = 1-total
    tp = {}
    tp['team_player'] = total
    return tp

@app.get("/v1/recordings/{selected_id}/goalDriveScore") 
async def goal_drive(selected_id):
    interview_id=selected_id
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      ,a.std
      ,a.interview_id
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Ambition','Determined','Engaged', 'Opportunistic')
      order by variable asc
      """.format(interview_id)
 
    df = dao.get_data(sql)
    total=df['mean'].sum()
    total=(total/4).round(decimals=3)
    missing = 1-total
    gd = {}
    gd['goal_drive'] = total
    return gd

@app.get("/v1/recordings/{selected_id}/socialableLevelScore") 
def socialable(selected_id):
    interview_id=selected_id
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      ,a.std
      ,a.interview_id
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Attentive','Communication','Communicative', 'Cooperation', 'Energy', 'Extraversion', 'Sales Skills', 'Social', 'Social Skills', 'Temperament')
      order by variable asc
      """.format(interview_id)

    df = dao.get_data(sql)
    total=df['mean'].sum()
    total=(total/10).round(decimals=3)
    missing = 1-total
    sl = {}
    sl['social_level'] = total
    return sl

@app.get("/v1/recordings/{selected_id}/emotionalWellbeingScore") 
async def emotional_wellbeing(selected_id):
    interview_id = selected_id
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      ,a.std
      ,a.interview_id
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Burnout','Coping','Determined', 'Emotional Stability', 'Emotional State', 'Energy', 'Stress Control', 'Well Being')
      order by variable asc
      """.format(interview_id)

    df = dao.get_data(sql)
    #make burnout 1 - burnout so it is consistent with positive values for objectivity
    bo = df.loc[df['variable']=='Burnout', 'mean']
    df.loc[df['variable']=='Burnout', 'mean'] = 1-bo    
    total=df['mean'].sum()
    total=(total/8).round(decimals=3)
    missing = 1-total
    ewb = {}
    ewb['emotional_wellbeing'] = total
    return ewb

@app.get("/v1/recordings/{selected_id}/cohesionScore") 
async def cohesion(selected_id):
    interview_id=selected_id
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      ,a.std
      ,a.interview_id
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Attitude','Communication','Communicative', 'Conscientiousness', 'Cooperation', 'Creative-Thinker', 'Emotional Stability', 'Engaged', 'Extraversion', 'Openness', 'Social', 'Social Skills', 'Well Being')
      order by variable asc
      """.format(interview_id)

    df = dao.get_data(sql)
    total=df['mean'].sum()
    total=(total/13).round(decimals=3)
    missing = 1-total
    coh = {}
    coh['cohesion'] = total    
    return coh

@app.get("/v1/recordings/{selected_id}/autonomyScore") 
async def autonomy(selected_id):
    interview_id=selected_id
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      ,a.std
      ,a.interview_id
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Adaptive', 'Adjustment', 'Attentive', 'Attitude','Creative-Artistically','Creative-Thinker', 'Determined', 'Energy', 'Openness', 'Stress Control', 'Temperament')
      order by variable asc
      """.format(interview_id)

    df = dao.get_data(sql)
    total=df['mean'].sum()
    total=(total/11).round(decimals=3)
    missing = 1-total
    aut = {}
    aut['autonomy'] = total
    return aut

@app.get("/v1/recordings/{selected_id}/subjectivityScore") 
async def subjectivity(selected_id):
    
    interview_id=selected_id
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      ,a.std
      ,a.interview_id
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Adjustment', 'Burnout', 'Communication','Conscientiousness','Dependable', 'Emotional Stability', 'Emotional State', 'Learning', 'Temperament')
      order by variable asc
      """.format(interview_id)

    df = dao.get_data(sql)
    bo = df.loc[df['variable']=='Burnout', 'mean']
    df.loc[df['variable']=='Burnout', 'mean'] = 1-bo
#    print(df.loc[df['variable']=='Burnout', 'mean'])

    total=df['mean'].sum()
    total=(total/9)
    #missing and total represent objectivity therefore flip for subjectivity
    total = 1 - total
    
    missing = 1-total
    sub = {}
    sub['subjectivity'] = total.round(decimals=3)
    return sub

@app.get("/v1/recordings/{selected_id}/extrovertScore") 
async def extrovert(selected_id):
    
    interview_id=selected_id
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      ,a.std
      ,a.interview_id
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Communication','Communicative','Emotional State', 'Openness', 'Extraversion', 'Openness', 'Social', 'Social Skills')
      order by variable asc
      """.format(interview_id)

    df = dao.get_data(sql)
    names = ['A', 'B']
    total=df['mean'].sum()
    total=(total/8).round(decimals=3)
    missing = 1-total
    extro = {}
    extro['extrovert'] = total
    return extro

@app.get("/v1/recordings/{selected_id}/positiveMoodScore") 
async def depression(selected_id):
    interview_id=selected_id
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      ,a.std
      ,a.interview_id
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Burnout', 'Coping','Emotional Stability','Emotional State', 'Energy', 'Satisfaction', 'Stress Control', 'Well Being')
      order by variable asc
      """.format(interview_id)

    df = dao.get_data(sql)
    #make burnout 1 - burnout so it is consistent with positive values for objectivity
    bo = df.loc[df['variable']=='Burnout', 'mean']
    df.loc[df['variable']=='Burnout', 'mean'] = 1-bo
    names = ['A', 'B']
    total=df['mean'].sum()
    total=(total/8).round(decimals=3)
    missing = 1-total
    mood = {}
    mood['positive_mood'] = total
    return mood   

@app.get("/v1/recordings/{selected_id}/sentimentScore") 
async def sentiment(selected_id):
    interview_id=selected_id
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      ,a.std
      ,a.interview_id
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Attitude', 'Emotional Stability','Emotional State', 'Energy', 'Engaged', 'Satisfaction', 'Social', 'Stress Control', 'Well Being')
      order by variable asc
      """.format(interview_id)

    df = dao.get_data(sql)
    total=df['mean'].sum()
    total=(total/9).round(decimals=3)
    missing = 1-total
    sent = {}
    sent['sentiment'] = total
    return sent  

@app.get("/v1/recordings/{selected_id}/introspectiveScore") 
async def introspective(selected_id):
    interview_id=selected_id
    sql = """
      select Distinct
      vmk.variable_label variable
      ,a.mean 
      ,a.std
      ,a.interview_id
      from interview_summary a
      inner join variable_master_key vmk on a.variable = vmk.variable and a.service_name = vmk.service_name 
      where a.interview_id = '{}' 
      and a.service_name like 'vs-%%' 
      and vmk.active_variable = 1
      and vmk.variable_label in ('Communication', 'Communicative','Cooperation', 'Emotional State', 'Extraversion', 'Openness', 'Social', 'Stress Control')
      order by variable asc
      """.format(interview_id)

    df = dao.get_data(sql)
    #extraversion, social skills, social are inverese factors on introspection
    ex = df.loc[df['variable']=='Extraversion', 'mean']
    df.loc[df['variable']=='Extraversion', 'mean'] = 1-ex
    sc = df.loc[df['variable']=='Social', 'mean']
    df.loc[df['variable']=='Social', 'mean'] = 1-sc
    scsk = df.loc[df['variable']=='Social Skills', 'mean']
    df.loc[df['variable']=='Social Skills', 'mean'] = 1-scsk
    total=df['mean'].sum()
    total=(total/8).round(decimals=3)
    missing = 1-total
    intro = {}
    intro['introspective'] = total
    return intro     
    

    
# MAIN
id = 'AK10010041956'
#print(Big5(id))
#print(Top6(id))
#print(Psychometrics(id))
#print(SocialTraits(id))
#print(PersonalityTraits(id))
#print(PerformanceTraits(id))
#print(EmotionalHealthTraits(id))
#print(team_player(id))
#print(goal_drive(id))
#print(socialable(id))
#print(emotional_wellbeing(id))
#print(cohesion(id))
#print(autonomy(id))
#print(subjectivity(id))
#print(extrovert(id))
#print(depression(id))
#print(sentiment(id))
#print(introspective(id))
