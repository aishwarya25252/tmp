import nltk; nltk.download('punkt')

### For testing
class GingerIt :
    def parse(self,s) :
        return {'result':s}
###

import pandas as df
from nltk.tokenize import sent_tokenize
from happytransformer import HappyTextToText, TTSettings # takes lesser time than transformers
#from gingerit.gingerit import GingerIt # grammar correction
from pytictoc import TicToc
#happy_common_gen = HappyTextToText("T5", "mrm8488/t5-base-finetuned-common_gen")
#happy_common_gen = HappyTextToText("T5", "vennify/t5-base-grammar-correction")
beam_args = TTSettings(num_beams=5, min_length=1, max_length=200)
df= df.read_excel('data/sentences.xlsx')
correct_grammar= GingerIt()
happy_paraphrase = HappyTextToText("T5", "Vamsi/T5_Paraphrase_Paws")
top_k_sampling_args = TTSettings(do_sample=True, top_k=120, top_p= 0.99, early_stopping=True, min_length=1, max_length=30)

def t5_spell_check(input_text):
#    result = happy_common_gen.generate_text(input_text, args=beam_args)
    happy_grammar = HappyTextToText("T5", "vennify/t5-base-grammar-correction")
#    happy_grammar = HappyTextToText("T5", "mrm8488/t5-base-finetuned-common_gen")
    result = happy_grammar.generate_text("gec: " + input_text, args=beam_args)
#    result = happy_grammar.generate_text("grammar: " + input_text, args=beam_args)    
    return result.text

def my_paraphrase(sentence):
  sentence = "paraphrase: " + sentence + " </s>"
  result = happy_paraphrase.generate_text(sentence, args=top_k_sampling_args)
  output= result.text
  return(output)

def fetch_phrase_str(col_name, attribute):
    row= df[df['Trait'].str.contains(attribute)]
    fetched_phrase= list(row[col_name])
#    print('attribute: ', attribute, ' col_name: ', col_name, ' phrase: ', fetched_phrase)
    return fetched_phrase[0]
    
def generate_summary_positive(positive_attributes, gender):
    summary_text= ''
    proverb_list= ['A very strong trait you have', 'You', 'The qualities you posses', 'And also you', 'Your key traits,', 'Other qualities shown, you','You possess being']
    if gender=='m': proverb= 'He' 
    elif gender=='f': proverb= 'She'
    else: proverb= 'You' #'The candidate ' 'They'# 

    i=0
    for attribute in positive_attributes:
#        sentence= proverb + ' ' + fetch_phrase_str('Positive', attribute)
        sentence=  proverb_list[i] + ' ' + fetch_phrase_str('Positive', attribute)
        sentence = correct_grammar.parse(sentence) # grammar correction by gingerit
        sentence= sentence['result']
        summary_text = summary_text+ sentence
        i=(i+1) % (len(proverb_list))

    summary_text= summary_text.replace(' it ', ' ' + proverb + ' ')
    
    return summary_text

def generate_summary_negative(negative_attributes, gender):
    summary_text= ''
    if gender=='m': proverb= 'He' 
    elif gender=='f': proverb= 'She'
    else: proverb= 'You' #'The candidate ' 'They'# 

#    summary_text= 'On the downside, the assessment results indicate that '
    summary_text= 'The assessment results indicate that '            
    for ctr, attribute in enumerate(negative_attributes):
        if ctr==len(negative_attributes)-1:
#            sentence= ' Also, ' + proverb + ' ' + fetch_phrase_str('Negative', attribute)
            sentence= proverb + ' ' + fetch_phrase_str('Negative', attribute)            
        else:
            sentence= ' ' + proverb + ' ' + fetch_phrase_str('Negative', attribute)
        summary_text = summary_text+ sentence

    summary_text= summary_text.replace(' it ', ' ' + proverb + ' ')    
    return summary_text


def generate_paraphrase(summary_text):
    summary_paraphrased = " ".join([my_paraphrase(sent) for sent in sent_tokenize(summary_text)])
    return summary_paraphrased

def generate_narrative(positive_attributes, negative_attributes):
    t = TicToc() #create instance of class
#    print('GEN NARRATIVE POS: ', positive_attributes)
#    print('GEN NARRATIVE NEG: ', negative_attributes)
#    correct_grammar= GingerIt() 
 # # top_p close to 1 = more random AI
#    df= df.read_excel('data/sentences.xlsx')

    gender= ''
    corrected_summary2_pos = []
    corrected_summary2_neg = []
    if len(positive_attributes) != 0:
#        print("not empty positive attributes")
        print("step 1: generating summary...")
        t.tic()
        summary_text_pos= generate_summary_positive(positive_attributes, gender)
        print("step 2: generating paraphrase...")
        summary_paraphrased_pos= generate_paraphrase(summary_text_pos)
        print('step 3: correcting grammar through Google"s T5 model...') 
        corrected_summary1_pos= t5_spell_check(summary_paraphrased_pos) # gingerit is faster, by around 0.4 seconds  
        corrected_text_pos = correct_grammar.parse(corrected_summary1_pos) # grammar correction by gingerit
        corrected_summary2_pos= corrected_text_pos['result']         
        t.toc()

    if len(negative_attributes) != 0:
#        print("not empty negative attributes")
        print("step 1: generating summary...")
        t.tic()
        summary_text_neg= generate_summary_negative(negative_attributes, gender)
        print("step 2: generating paraphrase...")        
        summary_paraphrased_neg= generate_paraphrase(summary_text_neg)
        print('step 3: correcting grammar through Google"s T5 model...')
        corrected_summary1_neg= t5_spell_check(summary_paraphrased_neg) # gingerit is faster, by around 0.4 seconds
        corrected_text_neg = correct_grammar.parse(corrected_summary1_neg) # grammar correction by gingerit
        corrected_summary2_neg= corrected_text_neg['result']
        t.toc()
        print('corrected summary: ', corrected_summary2_neg)
    return(corrected_summary2_pos, corrected_summary2_neg)
    # corrected_summary= corrected_summary.capitalize()


##MAIN
#positive_attributes= ['Leadership', 'Systematic', 'Adjustment', 'Sales Skills']
#negative_attributes= ['Leadership', 'Emotional State', 'Energy']    
#result = generate_narrative(positive_attributes, negative_attributes)
#print('\nPERSONALITY ANALYSIS REPORT:\n')
#print('Strengths:')
#print(result[0])
#print('\nWeaknesses:')
#print(result[1])
