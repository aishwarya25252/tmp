var faq = document.getElementsByClassName("faq-page");
var i;
for (i = 0; i < faq.length; i++) {
    faq[i].addEventListener("click", function () {
        /* Toggle between adding and removing the "active" class,
        to highlight the button that controls the panel */
        this.classList.toggle("active");
        /* Toggle between hiding and showing the active panel */
        var body = this.nextElementSibling;
        if (body.style.display === "block") {
            body.style.display = "none";
        } else {
            body.style.display = "block";
        }
    });
}

function FirstQuestionLogic() {
console.log("inside firstlogic ");

    const audio = document.querySelector('audio');
    console.log('test ' + audio.currentTime + ' dur ' +audio.duration);
//    if (audio.currentTime < 3 || isNaN(audio.duration)) {
    var state = recorder.getState();
    if((state == 'stopped' && audio.duration < 60) || (state == 'recording' && audio.currentTime < 3)){
/*       document.getElementById("nextstep").setAttribute("onclick", "javascript: FirstQuestion();"); */
       document.getElementById('info').innerHTML="<p style='font-family:Courier; font-size: 12px; color:red;'>recording needs to be 60 seconds or longer</p>";
    } else {
/*       document.getElementById("nextstep").setAttribute("onclick", "javascript: SecondQuestion();");*/
       btnStopRecording.onclick();
       
       document.getElementById('info').innerHTML="";
       var blob = recorder.getBlob();
       // generating a random file name
       //var fileName = getFileName('ogg');
       //console.log(fileName);
       var email = sessionStorage.getItem("userid");
       var password = sessionStorage.getItem("userpwd");
       var cleanEmail = email.replace(/[^\w ]/g, '');
       var fileName = cleanEmail + "_q1.ogg";
       console.log(fileName);
       //var data = '{"service": "generate", "email": "' + email + '", "password": "' + password + '", "name": "' + fileName + '"}';
       var data = '{"name": "' + fileName + '"}';
       
       console.log("new test data: " + data);
       uploadCredentials(data, callbackUrl);
//       btnDownloadRecording.onclick();
       SecondQuestion();      
    }
}

function callbackUrl(callback)
{
       console.log('test callback');
       console.log(callback.body);
       var blob = recorder.getBlob();
       uploadBlob(callback.body, blob);       //blob
}
function SecondQuestionLogic() {
    const audio = document.querySelector('audio');
    var state = recorder.getState();
    if((state == 'stopped' && audio.duration < 60) || (state == 'recording' && audio.currentTime < 3)){
       document.getElementById('info').innerHTML="<p style='font-family:Courier; font-size: 12px; color:red;'>recording needs to be 60 seconds or longer</p>";
    } else {
       document.getElementById('info').innerHTML="";
       var blob = recorder.getBlob();
       //var fileName = getFileName('ogg');
       console.log(fileName);
       var email = sessionStorage.getItem("userid");
       var password = sessionStorage.getItem("userpwd");
       var cleanEmail = email.replace(/[^\w ]/g, '');
       var fileName = cleanEmail + "_q2.ogg";
       console.log(fileName);
//       var data = '{"service": "generate", "email": "' + email + '", "password": "' + password + '", "name": "' + fileName + '"}';
       var data = '{"name": "' + fileName + '"}';
       uploadCredentials(data, callbackUrl);            
//       btnDownloadRecording.onclick();
       ThirdQuestion();      
    }
}

function FirstQuestion() {
//    console.log('test param: ' + sessionStorage.getItem("userid"));
    faq[0].firstChild.nodeValue="First Question";
    document.getElementById('replace-me').style.fontSize="28px";
    document.getElementById('replace-me').innerText="Tell me about what you’ve been doing the last year.";
    document.getElementById("replace-me").setAttribute("style", "font-size: 18px; font-style: italic;");    
    document.getElementById("faq-body-id").setAttribute("style", "justify-content: center; text-align: center;");
    document.getElementById('replace-me-2').innerText="";
    var ac = document.getElementById("audio-container");
    ac.style.display = "block";
    const audio = document.querySelector('audio');
    document.getElementById('info').innerHTML="<p style='font-family:Courier; font-size: 12px; color:green;'>you must speak your answer for at least 60 seconds</p>";
    document.getElementById("nextstep").setAttribute("onclick", "javascript: FirstQuestionLogic();");
}

function SecondQuestion() {
    faq[0].firstChild.nodeValue="Second Question";
    document.getElementById('replace-me').innerText="Where do you see yourself going in the next year?";
    document.getElementById("nextstep").setAttribute("onclick", "javascript: SecondQuestionLogic();");
    document.getElementById('info').innerHTML="<p style='font-family:Courier; font-size: 12px; color:green;'>you must speak your answer for at least 60 seconds</p>";
}

function ThirdQuestion() {
    var ac = document.getElementById("audio-container");
    ac.style.display = "none";
    document.getElementById('artifact').innerHTML = "<br/>"
    faq[0].firstChild.nodeValue="Survey";
    document.getElementById('replace-me').innerText="Overall how would you rate this service?";
    document.getElementById('survey').innerHTML = '<div class="rate" style="display: inline-block; width:25%;"><input type="radio" id="star5" name="rate" value="5" /><label for="star5" title="">5 stars</label><input type="radio" id="star4" name="rate" value="4" /><label for="star4" title="">4 stars</label><input type="radio" id="star3" name="rate" value="3" /><label for="star3" title="">3 stars</label><input type="radio" id="star2" name="rate" value="2" /><label for="star2" title="">2 stars</label><input type="radio" id="star1" name="rate" value="1" /><label for="star1" title="">1 star</label></div><div></div>';
    document.getElementById('info').innerHTML="";
    document.getElementById("nextstep").setAttribute("onclick", "javascript: FourthQuestion();");
}

function FourthQuestion() {
    document.getElementById('artifact').innerHTML = ""
    faq[0].firstChild.nodeValue="Survey";
//    var body = document.getElementsByClassName("faq-body");
    document.getElementById('replace-me').innerText="How would you rate your level of Agreeableness?";
    document.getElementById('survey').innerHTML = '<div class="slider"><input type="range" min="0" max="100" value="50" oninput="rangeValue.innerText = this.value"><p id="rangeValue">50</p></div>';
    document.getElementById("nextstep").setAttribute("onclick", "javascript: FifthQuestion();");
}

function FifthQuestion() {
    faq[0].firstChild.nodeValue="Thank you!";
//    var body = document.getElementsByClassName("faq-body");
    document.getElementById('replace-me').innerText="You are all done! Click the Next button to see your results";
    document.getElementById('survey').innerHTML = '';
    var reportid_t = sessionStorage.getItem("userid");
    var reportid = reportid_t.replace(/[^\w ]/g, '');
    var reporturl = 'http://3.218.142.151/?id='+ reportid;
    document.getElementById("nextstep").setAttribute("onclick", "window.location.href =" + "'" + reporturl + "'");
}

function uploadCredentials(data, onSuccess)
{
       var resp;
       console.log('uploadCredentials');
       let xhr = new XMLHttpRequest();
       xhr.open("POST", "https://mccxbe9n2f.execute-api.us-east-1.amazonaws.com/test");
//      xhr.setRequestHeader("Accept", "application/json");
       xhr.setRequestHeader("Content-Type", "application/json");

       xhr.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
             var obj = new Object();
             console.log(this.responseText);
             obj = JSON.parse(this.responseText);
             onSuccess(obj);
          }
        }
        xhr.send(data);
}

function uploadBlob(url, blob) {
       fetch(url, {
          method: 'PUT',
          body: new File([blob], 'lol')
      }).then(response => {
        console.log(response) 
      });

}

