function validateEmail(email)
{
        var re = /^\S+@\S+\.\S+$/;   /* /^[^\s@]+@[^\s@]+\.[^\s@]+$/; /*      /^\S+@\S+\.\S+$/;*/  /\S+@\S+\.\S+/
        return re.test(email);
}

function upload(data, onSuccess)
{
       var resp;
       console.log('upload');
       let xhr = new XMLHttpRequest();
       xhr.open("POST", "https://mccxbe9n2f.execute-api.us-east-1.amazonaws.com/test");
//      xhr.setRequestHeader("Accept", "application/json");
       xhr.setRequestHeader("Content-Type", "application/json");
//      xhr.onload = () => console.log(xhr.responseText);
       xhr.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
             var obj = new Object();
             console.log(this.responseText);
             obj = JSON.parse(this.responseText);
             onSuccess(obj); //add check for url before here
          }
        }
        xhr.send(data);
}

function processSignup(email) 
{
        console.log('processSignup');
        if (validateEmail(email)===false){
           document.getElementById('status').innerHTML="<p style='font-family:Courier; font-size: 12px; color:red;'>incorrect email entered, please reenter</p>";
        }
        else {
           document.getElementById('status').innerHTML="<p style='font-family:Courier; font-size: 12px; color:green;'>now submitting your credentials</p>";
           var data = '{"service": "signup", "email": "' + document.getElementById('field1').value + '", "password": "' +  document.getElementById('field2').value + '"}';
           document.getElementById("userid").value=document.getElementById('field1').value;
           document.getElementById("userpwd").value=document.getElementById('field2').value;
//           loadApplication(); // remove after test
           upload(data, verify);
           //delete verify();
        }
}

function processVerify()
{
       console.log('processVerify');
       document.getElementById('status').innerHTML="<p style='font-family:Courier; font-size: 12px; color:green;'>verifying email code</p>";
       var data = '{"service": "verify", "email": "' + document.getElementById('field1').value + '", "code": "' +  document.getElementById('field2').value + '"}';
       upload(data, loadApplication);
}

function processResend()
{
       console.log('processResend');
       var data = '{"service": "resend", "email": "' + document.getElementById('field1').value + '"}';
       upload(data, verify);
}

function verify(callback)
{
       console.log('verify');
       console.log(callback.value);
       document.getElementById('field2-label').textContent = "Code: ";
       document.getElementById('field2').value = "";
       document.getElementById('field2').setAttribute("type", "text");
       document.getElementById("submitbutton").setAttribute("onclick", "javascript: processVerify();");
       document.getElementById("submitbutton").setAttribute("value", "Verify");
       document.getElementById('status').innerHTML="<p style='font-family:Courier; font-size: 12px; color:green;'>please enter the Code from the email sent to you</p><p style='font-family:Courier; font-size: 12px; color:green;'>to resend email <a href='javascript:processResend();'>click here</a>";
}

function loadApplication(callback)
//function loadApplication()
{
       console.log('loadApplication');
       console.log(callback);
       document.getElementById("userid").value=document.getElementById('field1').value;
       document.getElementById("userpwd").value=document.getElementById('field2').value;
       console.log(callback + ' length: ' + document.getElementById("userid").value.length);
       if((callback === 'success') && (document.getElementById("userid").value.length > 0)) {
//       if((document.getElementById("userid").value.length > 0)) {       
          var uid = document.getElementById("userid").value;
          var upwd = document.getElementById("userpwd").value;;
          sessionStorage.setItem("userid", uid);
          sessionStorage.setItem("userpwd", upwd);
          console.log("loading app");
          window.location.href = "app.html";
          document.getElementById("userid").value=uid;
          document.getElementById("userpwd").value=upwd;
       }      
}

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('field1').addEventListener('focus', function() {
        document.getElementById('status').textContent="";
    });
});
