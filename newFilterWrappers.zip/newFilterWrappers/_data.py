import pandas as pd
from os.path import dirname
class Data:
    def __init__(self):
        pass

    @staticmethod

    def colon():
        return pd.read_csv(dirname(__file__)+"/data/colon.csv",sep="\t",header=None)

    @staticmethod

    def splitter(data):
        return data[data.columns[:-1]],data[data.columns[-1]]
