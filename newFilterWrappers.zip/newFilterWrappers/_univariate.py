import sklearn.feature_selection as ft
import numpy as np
import scipy.stats as st
from skfeature.function.similarity_based import fisher_score
from skfeature.function.statistical_based import gini_index
from skfeature.function.statistical_based import t_score
from skfeature.function.similarity_based import reliefF
class Univariate:
    def __init__(self,df,target):
        self.data=np.array(df)
        self.lables=np.array(target)

    def chi_square(self):
        d=self.data.copy()
        l=self.lables.copy()
        score,p=ft.chi2(d,l)
        return score

    def mutual_information(self):
        d=self.data.copy()
        l=self.lables.copy()
        score=ft.mutual_info_classif(d,l)
        return score

    def annova_f(self):
        d=self.data.copy()
        l=self.lables.copy()
        score,p=ft.f_classif(d,l)
        return score

    def pearson_correlation_coefficient(self):
        d=self.data.copy()
        l=self.lables.copy()
        d=d.T
        score=list()
        for i in d:
            score.append(st.pearsonr(i,l)[0])
        score=np.array(score)
        return score

    def relief(self,i=5):
        d=self.data.copy()
        l=self.lables.copy()
        weights=np.zeros(d.shape[1])

        def manhattan(a,b):
            tmp=np.abs(a-b)
            return np.sum(tmp)

        def diff(a,instance_no,hm_no,d):
            tmp=np.abs(d[instance_no,a]-d[hm_no,a])
            return np.sum(tmp)

        def hit_miss_calc(instance_no,d,l):
            for i in range(d.shape[0]):
                hit_no=0
                miss_no=0
                hit_distance=None
                miss_distance=None
                if(i!=instance_no):
                    distance=manhattan(d[instance_no],d[i])
                    if(l[i]==1 and hit_distance==None):
                        hit_no=i
                        hit_distance=distance
                    if(l[i]==0 and miss_distance==None):
                        miss_no=i
                        miss_distance=distance
                    if(l[i]==1 and hit_distance!=None and distance < hit_distance):
                        hit_no=i
                        hit_distance=distance
                    if(l[i]==0 and miss_distance!=None and distance < miss_distance):
                        miss_no=i
                        miss_distance=distance

            return hit_no,miss_no

        for j in range(i):
            instance_no=np.random.randint(d.shape[0])
            hit_no,miss_no=hit_miss_calc(instance_no,d,l)
            for a in range(weights.shape[0]):
                weights[a]=weights[a]-(diff(a,instance_no,hit_no,d)-diff(a,instance_no,miss_no,d))/i
        score=np.array(weights)
        return score

    def fisher_score(self):
        d=self.data.copy()
        l=self.lables.copy()
        score=fisher_score.fisher_score(d,l)
        return score

    def gini_index(self):
        d=self.data.copy()
        l=self.lables.copy()
        score=gini_index.gini_index(d,l)
        return score

    def t_score(self):
        d=self.data.copy()
        l=self.lables.copy()
        score=t_score.t_score(d,l)
        return score

    def relief_f(self):
        d=self.data.copy()
        l=self.lables.copy()
        score=reliefF.reliefF(d,l)
        return score

    def signal_to_noise_ratio(self):
        d=self.data.copy()
        l=self.lables.copy()
        def signaltonoise(a, axis=0, ddof=0):
            a = np.asanyarray(a)
            m = a.mean(axis)
            sd = a.std(axis=axis, ddof=ddof)
            return np.where(sd == 0, 0, m/sd)
        score=signaltonoise(d)
        return score

