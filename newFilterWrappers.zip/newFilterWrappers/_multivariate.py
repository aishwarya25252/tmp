import numpy as np
from skfeature.function.information_theoretical_based import MRMR
from skfeature.function.information_theoretical_based import FCBF
class Multivariate:
    def __init__(self,df,target):
        self.data=np.array(df)
        self.lables=np.array(target)

    def MRMR(self):
        d=self.data.copy()
        l=self.lables.copy()
        sorted_features=MRMR.mrmr(d, l, n_selected_features=d.shape[1])[0]
        return sorted_features

    def FCBF(self):
        d=self.data.copy()
        l=self.lables.copy()
        features=d.shape[1]
        feature_list=list()
        for i in range(features):
            feature_list.append(float(FCBF.fcbf(d.T[i].T.reshape(-1,1),l)[1]))
        score=np.array(feature_list)
        return score

    def MIFS(self):
        d=self.data.copy()
        l=self.lables.copy()
        sorted_features=MIFS.mifs(d, l,n_selected_features=d.shape[1])[0]
        return sorted_features


