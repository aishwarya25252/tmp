import numpy as np
class BinaryGA:
    def __init__(self,data,labels,evaluator,classifier):
        data=np.array(data)
        labels=np.array(labels)
        self.d=data
        self.l=labels
        self.evl=evaluator
        self.cls=classifier
        self.feature_no=data.shape[1]
        self.best_accuracy=0
        self.global_best=np.zeros(self.feature_no)

    def optimizer_func(self,generation_matrix):
        a=list()
        for i in generation_matrix:
            if i.any() == False:
                a.append(1)
            else :
                index=i.nonzero()
                a.append(1-(self.evl(self.d.T[index].T,self.l,self.cls)))
        return np.array(a)

    def fitness_test(self):
        self.score=self.optimizer_func(self.generation)
        self.index=self.score.argsort()
        self.accuracy=1-self.score
        self.global_best=self.generation[self.index[0]]
        self.best_accuracy=self.accuracy[self.index[0]]
        pass

    def parent_selection(self):
        self.parent1=self.generation[self.index[0]]
        self.parent2=self.generation[self.index[1]]
        pass

    def crossover(self,cp):
        middle=int(self.feature_no/2)
        parent1part1=self.parent1[:middle]
        parent2part1=self.parent2[:middle]
        parent1part2=self.parent1[middle:]
        parent2part2=self.parent1[middle:]
        self.cross1=np.concatenate([parent1part1,parent2part2])
        self.cross2=np.concatenate([parent2part1,parent1part2])
        pass

    def mutation(self,Mp):
        for i in range(self.population):
            tmp=self.generation[i]
            pos=np.random.choice(range(self.feature_no))
            tmp[pos]=1-tmp[pos]
            self.generation[i]=tmp
        pass

    def generation_update(self):
        self.generation[self.index[-1]]=self.cross1
        self.generation[self.index[-2]]=self.cross2
        pass

    def printinfo(self,number):
        print("accuracy:"+str(self.best_accuracy)+" iteration_no:"+str(number))

    def run(self,population_no,iteration,Cp,Mp):
        self.population=population_no
        self.generation=np.random.choice([0,1],size=[population_no,self.feature_no])
        for i in range(iteration):
            self.fitness_test()
            self.parent_selection()
            self.crossover(Cp)
            self.mutation(Mp)
            self.generation_update()
            self.printinfo(i)
        self.fitness_test()
        return self.best_accuracy,self.global_best








