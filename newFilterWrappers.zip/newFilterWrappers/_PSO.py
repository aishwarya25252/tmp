import numpy as np
import pyswarms as ps
class BinaryPSO:
    def __init__(self,data,labels,evaluator,classifier):
        data=np.array(data)
        labels=np.array(labels)
        self.d=data
        self.l=labels
        self.evl=evaluator
        self.cls=classifier
        self.feature_no=data.shape[1]

    def optimizer_func(self,generation_matrix):
        a=list()
        for i in generation_matrix:
            if i.any() == False:
                a.append(1)
            else :
                index=i.nonzero()
                a.append(1-(self.evl(self.d.T[index].T,self.l,self.cls)))
        return np.array(a)

    def run(self,particle_no,iteration,C1,C2,W,K,P):
        options={'c1':C1,'c2':C2,'w':W,'k':K,'p':P}
        p=ps.discrete.binary.BinaryPSO(particle_no,self.feature_no,options)
        self.result=p.optimize(self.optimizer_func,iteration)
        accuracy=1-self.result[0]
        print("accuracy:"+str(accuracy))
        return self.result[1].nonzero()



class PsoWrapper:
    def __init__(self,data,labels,particle_number,classifier):
        data=np.array(data)
        labels=np.array(labels)
        self.d=data
        self.l=labels
        self.p=particle_number
        self.cls=classifier
        self.features=data.shape[1]
        self.samples=data.shape[0]
        self.global_best=np.zeros(data.shape[1])

    def convert(self):
        pass

    def set_best(self):
        pass

    def update(self):
        pass

    def run(self,maxiter,c):
        self.position=np.random.rand(self.p,self.features)
        self.velocity=np.random.rand(self.p,self.features)
        self.convert()
        self.set_best()
        self.update()
        for i in range(maxiter):
            self.convert()
            self.set_best()
            self.update()
        self.save_results()

    def result(self):
        return self.global_best



