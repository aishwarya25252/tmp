import numpy as np
from sklearn.model_selection import KFold
from sklearn.model_selection import LeaveOneOut
class Bootstrap:
    def __init__(self,df):
        self.data=np.array(df)

    def resample(self,number):
        d=self.data.copy()
        sample=d.shape[0]
        indices=np.random.randint(sample,size=number)
        d=d[indices,:]
        return d

    def nonrepeat_resample(self,number):
        d=self.data.copy()
        sample=d.shape[0]
        rng=np.random.default_rng()
        indices=rng.choice(sample,size=number,replace=False)
        d=d[indices,:]
        return d

    def sorted_feature(self,score,number):
        d=self.data.copy()
        indices=np.argsort(score)
        sorted_data=d[:,indices[-number:]]
        return sorted_data

    def reverse_sorted_feature(self,score,number):
        d=self.data.copy()
        indices=np.argsort(score)
        sorted_data=d[:,indices[:number]]
        return sorted_data

    def data_change(self,df):
        self.data=np.array(df)
        return None

    def loocv(self,data,labels,classifier):
        data=np.array(data)
        labels=np.array(labels)
        loocv=LeaveOneOut()
        match=0
        for train_index, test_index in loocv.split(data):
            classifier.fit(data[train_index],labels[train_index])
            prediction=classifier.predict(data[test_index])
            if prediction==int(labels[test_index]):
                match=match+1
        accuracy=match/(data.shape[0])
        return accuracy

    def ten_fold(self,data,labels,classifier):
        data=np.array(data)
        labels=np.array(labels)
        kf = KFold(n_splits=10)
        total=0
        missmatch=0
        match=0
        for train_index, test_index in kf.split(data):
            classifier.fit(data[train_index],labels[train_index])
            for i in test_index :
                prediction=classifier.predict(data[i].reshape(1, -1))
                if prediction==int(labels[i]):
                    match=match+1
                total=total+1
        accuracy=match/total
        return accuracy

    def five_fold(self,data,labels,classifier):
        data=np.array(data)
        labels=np.array(labels)
        kf = KFold(n_splits=5)
        total=0
        missmatch=0
        match=0
        for train_index, test_index in kf.split(data):
            classifier.fit(data[train_index],labels[train_index])
            for i in test_index :
                prediction=classifier.predict(data[i].reshape(1, -1))
                if prediction==int(labels[i]):
                    match=match+1
                total=total+1
        accuracy=match/total
        return accuracy








