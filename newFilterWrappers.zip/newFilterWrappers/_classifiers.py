from sklearn import tree
from sklearn import svm
from sklearn.linear_model import SGDClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier
class Classifiers:
    def __init__(self):
        self.all_classifiers=list()
        self.decision_tree=tree.DecisionTreeClassifier()
        self.all_classifiers.append(self.decision_tree)
        self.support_vector_machine=svm.SVC()
        self.all_classifiers.append(self.support_vector_machine)
        self.support_vector_machine_linear=svm.LinearSVC()
        self.all_classifiers.append(self.support_vector_machine_linear)
        self.stochastic_gradient_descent=SGDClassifier(loss="hinge", penalty="l2", max_iter=5)
        self.all_classifiers.append(self.stochastic_gradient_descent)
        self.gaussian_naive_bayes=GaussianNB()
        self.all_classifiers.append(self.gaussian_naive_bayes)
        self.neural_net_MLP=MLPClassifier(alpha=1, max_iter=1000)
        self.all_classifiers.append(self.neural_net_MLP)
        pass

    def fit_all_classifiers(self,x,y):
        for i in self.all_classifiers :
            i.fit(x,y)
        return None

